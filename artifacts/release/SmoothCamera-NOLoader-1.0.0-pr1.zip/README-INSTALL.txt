﻿Smooth Camera AutoCenter — NOLoader mod (pre-release 1.0.0-pr1 / DEV2SP40)
Extract NOLoader/mods/SmoothCamera into Nuclear Option game root (game CLOSED).
Requires NOLoader RDYTU core: https://github.com/Mursisru/NOLoader
Config: NOLoader/mods/SmoothCamera/mod_config.ini
